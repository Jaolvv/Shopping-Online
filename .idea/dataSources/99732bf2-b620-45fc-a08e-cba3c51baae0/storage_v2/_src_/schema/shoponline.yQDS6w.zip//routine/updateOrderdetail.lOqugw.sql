create
    definer = ``@`` procedure updateOrderdetail(IN oid int)
begin 
	set @price=0;
	set @quantitys=0;
	select p_price into @price from product where p_id=
	(select p_id from orderdetail where o_id=oid);
	select quantity into @quantitys from orderdetail where o_id=oid;
	set @sum=@price*@quantitys;
	update orderdetail set price=@sum where o_id=oid;
end;

