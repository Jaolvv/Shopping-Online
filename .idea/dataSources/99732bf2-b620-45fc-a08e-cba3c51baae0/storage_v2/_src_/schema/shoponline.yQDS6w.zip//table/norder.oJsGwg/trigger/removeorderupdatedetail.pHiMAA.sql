create definer = root@localhost trigger removeOrderUpdateDetail
    after delete
    on norder
    for each row
begin
		set @no_id=old.no_id;
		delete from orderdetail where no_id=@no_id;
end;

